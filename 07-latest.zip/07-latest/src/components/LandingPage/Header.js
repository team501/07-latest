/**
 * App Header
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import { Link } from 'react-router-dom';
import screenfull from 'screenfull';
import Tooltip from '@material-ui/core/Tooltip';
import MenuIcon from '@material-ui/icons/Menu';
import { withRouter } from 'react-router-dom';
import $ from 'jquery';
import ThemeOptions from './ThemeOptions';

// actions
import { collapsedSidebarAction } from 'Actions';

// helpers
import { getAppLayout } from "Helpers/helpers";

// components
import Notifications from '../Header/Notifications';
import ChatSidebar from '../Header/ChatSidebar';
import DashboardOverlay from '../DashboardOverlay/DashboardOverlay';
import LanguageProvider from '../Header/LanguageProvider';
import SearchForm from '../Header/SearchForm';
import HeaderQuick from '../Header/HeaderQuick';
import MobileSearchForm from '../Header/MobileSearchForm';
import UserBlock from './UserBlock';
//import Cart from './Cart';

// intl messages
import IntlMessages from 'Util/IntlMessages';

//fortna logo
import Logo from '../../assets/img/Fortna_logo.png';

//css
//import './landing.css';
 

class Header extends Component {

	state = {
		customizer: false,
		isMobileSearchFormVisible: false
	}

	// function to change the state of collapsed sidebar
	onToggleNavCollapsed = (event) => {
		const val = !this.props.navCollapsed;
		this.props.collapsedSidebarAction(val);
	}

	// open dashboard overlay
	openDashboardOverlay() {
		$('.dashboard-overlay').toggleClass('d-none');
		$('.dashboard-overlay').toggleClass('show');
		if ($('.dashboard-overlay').hasClass('show')) {
			$('body').css('overflow', 'hidden');
		} else {
			$('body').css('overflow', '');
		}
	}

	// close dashboard overlay
	closeDashboardOverlay() {
		$('.dashboard-overlay').removeClass('show');
		$('.dashboard-overlay').addClass('d-none');
		$('body').css('overflow', '');
	}

	// toggle screen full
	toggleScreenFull() {
		screenfull.toggle();
	}

	// mobile search form
	openMobileSearchForm() {
		this.setState({ isMobileSearchFormVisible: true });
	}

	render() {
		const { isMobileSearchFormVisible } = this.state;
		$('body').click(function () {
			$('.dashboard-overlay').removeClass('show');
			$('.dashboard-overlay').addClass('d-none');
			$('body').css('overflow', '');
		});
		const { horizontalMenu, agencyMenu, location } = this.props;
		return (
			<AppBar position="static" className="rct-header">
				<Toolbar className="d-flex justify-content-between w-100 pl-0">
					<div className="d-flex align-items-center">
						
						{!agencyMenu &&
							<ul className="list-inline mb-0 navbar-left">
								<li className="list-inline-item float-left" >
									<HeaderQuick />
								</li>
								<li className="list-inline-item logo">
									<Link to={`/landingpage`}> 
										<img src={Logo} className="logo-image"/> | <IntlMessages id="Dashboard.Header" /> 
									</Link>
								</li>
							</ul>
						}
						
					</div>
					<ul className="navbar-right list-inline dis-inherite mb-0">
						<li className="list-inline-item search-icon d-inline-block">
							<SearchForm />
							<IconButton mini="true" className="search-icon-btn" onClick={() => this.openMobileSearchForm()}>
								<i className="zmdi zmdi-search"></i>
							</IconButton>
							<MobileSearchForm
								isOpen={isMobileSearchFormVisible}
								onClose={() => this.setState({ isMobileSearchFormVisible: false })}
							/>
						</li>
						<LanguageProvider />
						{/*<Notifications /> // Removed from Header Notifications*/}  
						<li className="list-inline-item">
                          <ThemeOptions />
                           </li>
						<li className="list-inline-item">
							<UserBlock />
						</li>
						
						
					</ul>
					<Drawer
						anchor={'right'}
						open={this.state.customizer}
						onClose={() => this.setState({ customizer: false })}
					>
						<ChatSidebar />
					</Drawer>
				</Toolbar>
				<DashboardOverlay
					onClose={() => this.closeDashboardOverlay()}
				/>
			</AppBar>
		);
	}
}

// map state to props
const mapStateToProps = ({ settings }) => {
	return settings;
};

export default withRouter(connect(mapStateToProps, {
	collapsedSidebarAction
})(Header));
