import React from 'react';
import _ from 'lodash';
import ArcProgressbar from './ArcProgressbar';

// Component that renders an arbitrary
// number of divs on top of CircularProgressbar,
// whose content is centered.
function LayeredProgressbar(props) {
  const { renderOverlays, ...otherProps } = props;
  const overlayStyles = {
    position: 'absolute',
    height: '100%',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  };
  const overlays = props.renderOverlays();
  
  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
      }}
    >
      <div style={{ position: 'absolute', top:0, bottom:0, left:0, right:0 }}>
        <ArcProgressbar {...otherProps} 
          textForPercentage={null} 
          initialAnimation={false} 
        />
      </div>
      {overlays.map((overlay, index) => (
        <div style={overlayStyles} key={index}>
          {overlay}
        </div>
      ))}
    </div>
  );
}

function RadialSeparator(props) {
  return (
    <div
      className={"ArcOverlays"}
      style={{
        // background: "#ffffff",
        width: '3px',
        height: '100%',
        transform: `rotate(${216 + props.degrees}deg)`,
      }}
    />
  );
}

// Expects an even number of separators.
// Can be implemented with non-even numbers
// but requires changing the styling of LayeredProgressbar,
// left as exercise to the reader.
function getRadialSeparators(numSeparators) {
  const degrees = 360 / numSeparators;
  return _.range((numSeparators / 2)).map(index => (
    <RadialSeparator degrees={index * degrees} />
  ));
}

function SegmentedArcProgressbar(props) {
  return (
    <LayeredProgressbar
      percentage={props.percentage}
      strokeColors={props.segmentColors}
      segmentPercentage={props.segmentPercentage}
      strokeWidth={props.barWidth}
      styles={{
        path: {
          strokeLinecap: 'butt',
        },
      }}
      renderOverlays={() =>
        getRadialSeparators(1.51 * props.segments).concat(
          <div style={{color: props.textColor, fontSize: "x-large", fontWeight:"bold"}}>
            {props.percentage}%
          </div>,
        )
      }
    />
  );
}

export default SegmentedArcProgressbar;
